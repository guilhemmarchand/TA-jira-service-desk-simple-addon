# JIRA Service Desk simple addon

See: https://ta-jira-service-desk-simple-addon.readthedocs.io
